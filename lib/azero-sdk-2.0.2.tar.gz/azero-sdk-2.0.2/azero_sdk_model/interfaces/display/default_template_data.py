#!/anaconda3/envs/FEALPy/bin python3.7
# -*- coding: utf-8 -*-
# ---
# @Software: PyCharm
# @Site: 
# @File: default_template_data.py
# @Author: alston
# @E-mail: ---
# @Time: 2020-06-19 10:39:26
# ---

import pprint
import re  # noqa: F401
import six
import typing
from enum import Enum
from ask_sdk_model.interfaces.display.template import Template


if typing.TYPE_CHECKING:
    from typing import Dict, List, Optional, Union
    from datetime import datetime
    from azero_sdk_model.interfaces.display.image import Image
    from azero_sdk_model.interfaces.display.title import Title
    from azero_sdk_model.interfaces.display.ext_content import ExtContent


class DefaultTemplateData(Template):
    """
        :param token:
        :param back_button:
        :param background_image:
        :param title:
        :param ext_content:
        :param text_field:
    """
    deserialized_types = {
        'object_type': 'str',
        'token': 'str',
        'back_button': 'azero_sdk_model.interfaces.display.back_button_behavior.BackButtonBehavior',
        'background_image': 'azero_sdk_model.interfaces.display.image.Image',
        'title': 'azero_sdk_model.interfaces.display.title.Title',
        'ext_content': 'azero_sdk_model.interfaces.display.ext_content.ExtContent',
        'text_field': 'str'
    }  # type: Dict

    attribute_map = {
        'object_type': 'type',
        'token': 'token',
        'back_button': 'backButton',
        'background_image': 'backgroundImage',
        'title': 'title',
        'ext_content': 'extContent',
        'text_field': 'textField'
    }  # type: Dict
    supports_multiple_types = False

    def __init__(self, token=None, back_button=None, background_image=None, title=None, ext_content=None, text_field=None):
        # type: (Optional[str], Optional[str], Optional[Image], Optional[Title], Optional[ExtContent], Optional[str]) -> None
        """
            :param token:
            :type back_button: (optional) str
            :param back_button:
            :type back_button: (optional) azero_sdk_model.interfaces.display.back_button_behavior.BackButtonBehavior
            :param background_image:
            :type background_image: (optional) azero_sdk_model.interfaces.display.image.Image
            :param title:
            :type title: (optional) azero_sdk_model.interfaces.display.title.Title
            :param ext_content:
            :type ext_content: (optional) azero_sdk_model.interfaces.display.ext_content.ExtContent
            :param text_field:
            :type text_field: (optional) str
        """
        self.__discriminator_value = "DefaultTemplateData"  # type: str
        self.object_type = self.__discriminator_value
        super(DefaultTemplateData, self).__init__(object_type=self.__discriminator_value, token=token, back_button=back_button)
        self.token = token
        self.back_button = back_button

        self.background_image = background_image
        self.title = title
        self.ext_content = ext_content
        self.text_field = text_field

    def to_dict(self):
        # type: () -> Dict[str, object]
        """Returns the model properties as a dict"""
        result = {}  # type: Dict

        for attr, _ in six.iteritems(self.deserialized_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else
                    x.value if isinstance(x, Enum) else x,
                    value
                ))
            elif isinstance(value, Enum):
                result[attr] = value.value
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else
                    (item[0], item[1].value)
                    if isinstance(item[1], Enum) else item,
                    value.items()
                ))
            else:
                result[attr] = value

        return result

    def to_str(self):
        # type: () -> str
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        # type: () -> str
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        # type: (object) -> bool
        """Returns true if both objects are equal"""
        if not isinstance(other, DefaultTemplateData):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        # type: (object) -> bool
        """Returns true if both objects are not equal"""
        return not self == other
