#!/anaconda3/envs/FEALPy/bin python3.7
# -*- coding: utf-8 -*-
# ---
# @Software: PyCharm
# @Site: 
# @File: ext_field.py
# @Author: alston
# @E-mail: ---
# @Time: 2020-06-18 16:37:06
# ---

import pprint
import six
import typing
from enum import Enum


if typing.TYPE_CHECKING:
    from typing import Dict, Optional


class Title(object):
    """
        :param mainTitle:
        :type mainTitle: (optional) str
        :param subTitle:
        :type subTitle: (optional) str
    """
    deserialized_types = {
        'mainTitle': 'str',
        'subTitle': 'str'
    }  # type: Dict

    attribute_map = {
        'mainTitle': 'mainTitle',
        'subTitle': 'subTitle'
    }  # type: Dict
    supports_multiple_types = False

    def __init__(self, mainTitle=None, subTitle=None):
        # type: (Optional[str], Optional[str]) -> None
        """
            :param mainTitle:
            :type mainTitle: (optional) str
            :param subTitle:
            :type subTitle: (optional) str
        """
        self.__discriminator_value = None  # type: str

        self.mainTitle = mainTitle
        self.subTitle = subTitle

    def to_dict(self):
        # type: () -> Dict[str, object]
        """Returns the model properties as a dict"""
        result = {}  # type: Dict

        for attr, _ in six.iteritems(self.deserialized_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else
                    x.value if isinstance(x, Enum) else x,
                    value
                ))
            elif isinstance(value, Enum):
                result[attr] = value.value
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else
                    (item[0], item[1].value)
                    if isinstance(item[1], Enum) else item,
                    value.items()
                ))
            else:
                result[attr] = value

        return result

    def to_str(self):
        # type: () -> str
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        # type: () -> str
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        # type: (object) -> bool
        """Returns true if both objects are equal"""
        if not isinstance(other, Title):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        # type: (object) -> bool
        """Returns true if both objects are not equal"""
        return not self == other
