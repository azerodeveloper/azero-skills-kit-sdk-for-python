#!/anaconda3/envs/FEALPy/bin python3.7
# -*- coding: utf-8 -*-
# ---
# @Software: PyCharm
# @Site: 
# @File: ext_content.py
# @Author: alston
# @E-mail: ---
# @Time: 2020-06-19 10:43:20
# ---

import pprint
import six
import typing
from enum import Enum


if typing.TYPE_CHECKING:
    from typing import Dict, Optional


class ExtContent(object):
    """
        :param data:
        :type data: (optional) str
        :param type:
        :type type: (optional) str
        :param tts_text:
        :type tts_text: (optional) str
        :param asr_text:
        :type asr_text: (optional) str
    """
    deserialized_types = {
        'data': 'str',
        'type': 'str',
        'tts_text': 'str',
        'asr_text': 'str'
    }  # type: Dict

    attribute_map = {
        'data': 'data',
        'type': 'type',
        'tts_text': 'TTSText',
        'asr_text': 'ASRText'
    }  # type: Dict
    supports_multiple_types = False

    def __init__(self, data=None, type=None, tts_text=None, asr_text=None):
        # type: (Optional[str], Optional[str], Optional[str], Optional[str]) -> None
        """
            :param data:
            :type data: (optional) str
            :param type:
            :type type: (optional) str
            :param tts_text:
            :type tts_text: (optional) str
            :param asr_text:
            :type asr_text: (optional) str
        """
        self.__discriminator_value = None  # type: str

        self.data = data
        self.type = type
        self.tts_text = tts_text
        self.asr_text = asr_text

    def to_dict(self):
        # type: () -> Dict[str, object]
        """Returns the model properties as a dict"""
        result = {}  # type: Dict

        for attr, _ in six.iteritems(self.deserialized_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else
                    x.value if isinstance(x, Enum) else x,
                    value
                ))
            elif isinstance(value, Enum):
                result[attr] = value.value
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else
                    (item[0], item[1].value)
                    if isinstance(item[1], Enum) else item,
                    value.items()
                ))
            else:
                result[attr] = value

        return result

    def to_str(self):
        # type: () -> str
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        # type: () -> str
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        # type: (object) -> bool
        """Returns true if both objects are equal"""
        if not isinstance(other, Title):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        # type: (object) -> bool
        """Returns true if both objects are not equal"""
        return not self == other
