from flask_ask_sdk.skill_adapter import SkillAdapter
from ask_sdk_core.skill import CustomSkill
from flask import current_app, request as flask_request, jsonify, Response
from werkzeug import exceptions
from ask_sdk_webservice_support.verifier import (
    AbstractVerifier, VerificationException)
from ask_sdk_webservice_support import verifier_constants
from ask_sdk_core.exceptions import AskSdkException
from ask_sdk_model import RequestEnvelope


class AzeroSkillAdapter(SkillAdapter):

    def __init__(self, skill, skill_id, verifiers=None, app=None):
        # type: (CustomSkill, int, List[AbstractVerifier], Flask) -> None
        self._skill_id = skill_id
        self._skill = skill
        self._webservice_handler = None

        if verifiers is None:
            verifiers = []

        self._verifiers = verifiers

        if not isinstance(skill, CustomSkill):
            raise TypeError(
                "Invalid skill instance provided. Expected a custom "
                "skill instance.")

        if app is not None:
            self.init_app(app)

    def dispatch_request(self):
        # type: () -> Response

        if flask_request.method != "POST":
            raise exceptions.MethodNotAllowed()

        try:
            content = flask_request.data.decode(
                verifier_constants.CHARACTER_ENCODING)
            # print('flask content:'+content)

            request_envelope = self._skill.serializer.deserialize(
                payload=content, obj_type=RequestEnvelope)

            response_envelope = self._skill.invoke(
                request_envelope=request_envelope, context=None)

            response =  self._skill.serializer.serialize(response_envelope)

            return jsonify(response)
        except VerificationException:
            current_app.logger.error(
                "Request verification failed", exc_info=True)
            raise exceptions.BadRequest(
                description="Incoming request failed verification")
        except AskSdkException:
            current_app.logger.error(
                "Skill dispatch exception", exc_info=True)
            raise exceptions.InternalServerError(
                description="Exception occurred during skill dispatch")