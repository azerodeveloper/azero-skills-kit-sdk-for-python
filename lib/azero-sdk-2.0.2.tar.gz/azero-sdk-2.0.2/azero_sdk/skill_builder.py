#!/anaconda3/envs/FEALPy/bin python3.7
# -*- coding: utf-8 -*-
# ---
# @Software: PyCharm
# @Site: 
# @File: skill_builder.py
# @Author: alston
# @E-mail: ---
# @Time: 2020-05-06 16:32:24
# ---

from ask_sdk_core.skill_builder import SkillBuilder
from ask_sdk_core.api_client import DefaultApiClient

class AzeroSkillBuilder(SkillBuilder):
    def __init__(self):
        super(AzeroSkillBuilder, self).__init__()

    @property
    def skill_configuration(self):
        # type: () -> SkillConfiguration
        """Create the skill configuration object using the registered
        components.
        """
        skill_config = super(AzeroSkillBuilder, self).skill_configuration
        skill_config.api_client = DefaultApiClient()
        return skill_config