#!/anaconda3/envs/FEALPy/bin python3.7
# -*- coding: utf-8 -*-
# ---
# @Software: PyCharm
# @Site: 
# @File: test.py
# @Author: alston
# @E-mail: ---
# @Time: 2020-07-28 11:38:02
# ---

from Crypto.Cipher import AES
from binascii import b2a_hex, a2b_hex

text = '67ee697547ec0787fdeef6a612cbe990b4a85798fd6f17ce7bca6903b723cfc0d9f2a2214beb847046ffd809a9a9646934a228f347c4aad9ae2ecac5b07c9721c3d62837ed47074c4e1aacddd80e78cb410785e623d724fac6f657b8bf27faa173661982676d395f380e21d51c5ed870'
text = bytes(text, encoding='utf-8')
key = '4c0d7c0acb494224b3a44d0866ba99bf'.encode('utf-8')
mode = AES.MODE_ECB
cryptor = AES.new(key, mode)
plain_text = cryptor.decrypt(a2b_hex(text))
print(bytes.decode(plain_text).rstrip('\0'))