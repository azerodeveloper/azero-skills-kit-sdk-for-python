# -*- coding: utf-8 -*-
#
# Copyright 2018 Amazon.com, Inc. or its affiliates. All Rights
# Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS
# OF ANY KIND, either express or implied. See the License for the
# specific language governing permissions and limitations under the
# License.
#
import unittest
import pymongo
import os

from boto3.exceptions import ResourceNotExistsError
from ask_sdk_model import RequestEnvelope
from ask_sdk_core.exceptions import PersistenceException
from azero_sdk_mongodb.adapter import MongoDbPersistenceAdapter

try:
    import mock
except ImportError:
    from unittest import mock


os.environ['DBURL'] = 'mongodb://172.16.10.14:27017'
os.environ['DATABASES'] = 'azero_lwy'

class ResourceInUseException(Exception):
    pass


class TestMongoDbPersistenceAdapter(unittest.TestCase):
    def setUp(self):
        print('start')
        self.partition_keygen = mock.Mock()
        self.request_envelope = RequestEnvelope()
        self.expected_key_schema = [{'AttributeName': 'id', 'KeyType': 'HASH'}]
        self.expected_attribute_definitions = [
            {'AttributeName': 'id', 'AttributeType': 'S'}]
        self.expected_provision_throughput = {
            'ReadCapacityUnits': 5, 'WriteCapacityUnits': 5}
        self.attributes = {"test_key111": [{"liu":{"liu1":"wen1222"}},{"liu1":{"liu11":"wen11"}}]}
        self.create_table = True
        self.user_id = 'a8069581e67964680d9e762640f4c657'
        self.skill_id = '5e424886ba474b00088d4ab0'
        self.table_name = 'skill_test'
        self.mongo_client = pymongo.MongoClient('mongodb://172.16.11.12',27017)

        print('end')

    def test_save_attributes_to_existing(self):
        self.partition_keygen.return_value = "test_partition_key3333"

        test_mongodb_adapter = MongoDbPersistenceAdapter(
            request_envelope=self.request_envelope,
            table_name=self.table_name,
            partition_key_name="wenyuan",
            attribute_name="ssss",
            partition_keygen=self.partition_keygen)

        test_mongodb_adapter.save_attributes(
            request_envelope=self.request_envelope, attributes=self.attributes)

    def test_get_attributes_from_existing(self):
        mock_table = mock.Mock()
        mock_table.get_item.return_value = {"attributes": self.attributes}
        self.partition_keygen.return_value = "test_partition_key3333"

        test_mongodb_adapter = MongoDbPersistenceAdapter(
            request_envelope=self.request_envelope,
            table_name=self.table_name,
            partition_key_name="wenyuan",
            # mongo_client=self.mongo_client,
            # db_name=self.db_name,
            partition_keygen=self.partition_keygen)

        response = test_mongodb_adapter.get_attributes(
            request_envelope=self.request_envelope)
        for result in response:
            print(result)

    def test_delete_attributes_to_existing(self):
        mock_table = mock.Mock()
        mock_table.delete_item.return_value = True
        self.partition_keygen.return_value = "test_partition_key3333"

        test_mongodb_adapter = MongoDbPersistenceAdapter(
            request_envelope=self.request_envelope,
            table_name=self.table_name,
            partition_key_name="wenyuan",
            # mongo_client=self.mongo_client,
            # db_name=self.db_name,
            partition_keygen=self.partition_keygen)

        test_mongodb_adapter.delete_attributes(
            request_envelope=self.request_envelope)
