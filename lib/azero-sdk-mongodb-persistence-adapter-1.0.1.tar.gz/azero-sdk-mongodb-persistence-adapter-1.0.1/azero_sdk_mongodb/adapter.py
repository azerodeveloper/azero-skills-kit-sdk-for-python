# -*- coding: utf-8 -*-
#
# Copyright 2018 Amazon.com, Inc. or its affiliates. All Rights
# Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS
# OF ANY KIND, either express or implied. See the License for the
# specific language governing permissions and limitations under the
# License.
#
import pymongo
import os
import typing

from ask_sdk_core.attributes_manager import AbstractPersistenceAdapter
from ask_sdk_core.exceptions import PersistenceException
from boto3.exceptions import ResourceNotExistsError

from .partition_keygen import user_id_partition_keygen
from azero_log.azero_logger import logger
logger.logger.name = "skill"

if typing.TYPE_CHECKING:
    from typing import Callable, Dict
    from ask_sdk_model import RequestEnvelope

def get_skill_id(requestEnvelope):
    if (requestEnvelope is None
            or requestEnvelope.context is None
            or requestEnvelope.context.system is None
            or requestEnvelope.context.system.application is None
            or requestEnvelope.context.system.application.application_id is None):
        # raise Exception("没有获取到skill_id")
        return ''
    else:
        return requestEnvelope.context.system.application.application_id

class MongoDbPersistenceAdapter(AbstractPersistenceAdapter):
    def __init__(
            self,
            request_envelope,
            table_name,
            partition_key_name="id",
            attribute_name="attributes",
            db_name=None,
            mongo_client=None,
            partition_keygen=user_id_partition_keygen):
        # type: (RequestEnvelope, str, str, str, str, str, Callable[[RequestEnvelope], str]) -> None
        """

        :param request_envelope:
        :param table_name:
        :param partition_key_name:
        :param attribute_name:
        :param db_name:
        :param mongo_client:
        :param partition_keygen:
        """
        db_url = os.environ.get('DBURL')
        skill_id = get_skill_id(request_envelope)
        if db_name is None:
            db_name = os.environ.get('DATABASES')

        if mongo_client is None:
            mongo_client = pymongo.MongoClient(db_url)
        self.__db_name = db_name
        self.table_name = table_name
        self.partition_key_name = partition_key_name
        self.attribute_name = attribute_name
        self.partition_keygen = partition_keygen
        self.request_envelope = request_envelope
        self.mongo_client = mongo_client
        self.__create_table_if_not_exists()
        self.skill_key_name = 'skill_id'
        self.skill_key_value = skill_id

    def get_attributes(self, request_envelope):
        # type: (RequestEnvelope) -> Dict[str, object]
        """Get attributes from table in Mongodb resource.

        Retrieves the attributes from Mongodb table. If the table
        doesn't exist, returns an empty dict if the
        ``create_table`` variable is set as True, else it raises
        PersistenceException. Raises PersistenceException if `get_item`
        fails on the table.

        :param request_envelope: Request Envelope passed during skill
            invocation
        :type request_envelope: ask_sdk_model.RequestEnvelope
        :return: Attributes stored under the partition keygen mapping
            in the table
        :rtype: Dict[str, object]
        :raises: :py:class:`ask_sdk_core.exceptions.PersistenceException`
        """
        try:
            client_db = self.mongo_client[self.__db_name]
            table = client_db[self.table_name]
            partition_key_val = self.partition_keygen(request_envelope)
            response = table.find({self.skill_key_name: self.skill_key_value,self.partition_key_name: partition_key_val})
            return response
        except ResourceNotExistsError:
            logger.error("MongoDb table {} doesn't exist or in the process of "
                "being created. Failed to get attributes from "
                "MongoDb table.".format(self.table_name),self.request_envelope)
            raise PersistenceException(
                "MongoDb table {} doesn't exist or in the process of "
                "being created. Failed to get attributes from "
                "MongoDb table.".format(self.table_name))
        except Exception as e:
            logger.error("Failed to retrieve attributes from MongoDb table. "
                "Exception of type {} occurred: {}".format(
                    type(e).__name__, str(e)),self.request_envelope)
            raise PersistenceException(
                "Failed to retrieve attributes from MongoDb table. "
                "Exception of type {} occurred: {}".format(
                    type(e).__name__, str(e)))

    def save_attributes(self, request_envelope, attributes):
        # type: (RequestEnvelope, Dict[str, object]) -> None
        """Saves attributes to table in Mongodb resource.

        Saves the attributes into Mongodb table. Raises
        PersistenceException if table doesn't exist or ``put_item`` fails
        on the table.

        :param request_envelope: Request Envelope passed during skill
            invocation
        :type request_envelope: ask_sdk_model.RequestEnvelope
        :param attributes: Attributes stored under the partition keygen
            mapping in the table
        :type attributes: Dict[str, object]
        :rtype: None
        :raises: :py:class:`ask_sdk_core.exceptions.PersistenceException`
        """
        try:
            # table = self.mongo_client[self.db_name][self.table_name]
            client_db = self.mongo_client[self.__db_name]
            table = client_db[self.table_name]
            table.create_index([(self.partition_key_name, 1)], unique=True)
            partition_key_val = self.partition_keygen(request_envelope)
            table.insert_one({self.skill_key_name: self.skill_key_value, self.partition_key_name: partition_key_val, self.attribute_name: attributes})

        except ResourceNotExistsError:
            logger.error("MongoDb table {} doesn't exist. Failed to save attributes "
                "to MongoDb table.".format(
                    self.table_name),self.request_envelope)
            raise PersistenceException(
                "MongoDb table {} doesn't exist. Failed to save attributes "
                "to MongoDb table.".format(
                    self.table_name))
        except Exception as e:
            logger.error("Failed to save attributes to MongoDb table. Exception of "
                "type {} occurred: {}".format(
                    type(e).__name__, str(e)),self.request_envelope)
            raise PersistenceException(
                "Failed to save attributes to MongoDb table. Exception of "
                "type {} occurred: {}".format(
                    type(e).__name__, str(e)))

    def delete_attributes(self, request_envelope):
        # type: (RequestEnvelope) -> None
        """Deletes attributes from table in Mongodb resource.

        Deletes the attributes from Mongodb table. Raises
        PersistenceException if table doesn't exist or ``delete_item`` fails
        on the table.

        :param request_envelope: Request Envelope passed during skill
            invocation
        :type request_envelope: ask_sdk_model.RequestEnvelope
        :rtype: None
        :raises: :py:class:`ask_sdk_core.exceptions.PersistenceException`
        """
        try:
            # table = self.mongo_client[self.db_name][self.table_name]
            client_db = self.mongo_client[self.__db_name]
            table = client_db[self.table_name]
            partition_key_val = self.partition_keygen(request_envelope)
            table.delete_many({self.skill_key_name: self.skill_key_value,self.partition_key_name: partition_key_val})
        except ResourceNotExistsError:
            logger.error("MongoDb table {} doesn't exist. Failed to delete attributes "
                "from MongoDb table.".format(
                    self.table_name),self.request_envelope)
            raise PersistenceException(
                "MongoDb table {} doesn't exist. Failed to delete attributes "
                "from MongoDb table.".format(
                    self.table_name))
        except Exception as e:
            logger.error("Failed to delete attributes in MongoDb table. Exception of "
                "type {} occurred: {}".format(
                    type(e).__name__, str(e)),self.request_envelope)
            raise PersistenceException(
                "Failed to delete attributes in MongoDb table. Exception of "
                "type {} occurred: {}".format(
                    type(e).__name__, str(e)))

    def __close_client__(self):
        try:
            self.mongo_client.close()
        except Exception as e:
            logger.error("Close Client ERROR "
                         "failed: Exception of type {} "
                         "occurred: {}".format(
                type(e).__name__, str(e)), self.request_envelope)
            raise Exception("Close Client ERROR "
                         "failed: Exception of type {} "
                         "occurred: {}".format(
                type(e).__name__, str(e)))


    def __create_table_if_not_exists(self):
        # type: () -> None
        """Creates table in Mongodb resource if it doesn't exist and
        create_table is set as True.

        :rtype: None
        :raises: PersistenceException: When `create_table` fails on
            Mongodb resource.
        """
        try:
            # self.mongo_client[self.db_name][self.table_name]
            client_db = self.mongo_client[self.__db_name]
            table = client_db[self.table_name]
        except Exception as e:
            if e.__class__.__name__ != "ResourceInUseException":
                logger.error("Create table if not exists request "
                    "failed: Exception of type {} "
                    "occurred: {}".format(
                        type(e).__name__, str(e)),self.request_envelope)
                raise PersistenceException(
                    "Create table if not exists request "
                    "failed: Exception of type {} "
                    "occurred: {}".format(
                        type(e).__name__, str(e)))