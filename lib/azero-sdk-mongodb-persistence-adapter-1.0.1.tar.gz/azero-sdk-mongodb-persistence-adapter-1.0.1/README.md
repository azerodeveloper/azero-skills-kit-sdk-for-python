
#  azero-sdk-mongodb-persistence-adapter for python

这是一个帮助开发Skill开发者实现技能持久化

用法如下：

项目根目录安装

pip install azero-sdk-mongodb-persistence-adapter-*.tar.gz

使用样例：

```python
# 1.引入BD持久化包
from azero_sdk_mongodb.adapter import MongoDbPersistenceAdapter


data = {"mongo_adapter":{"test":"test1"}}
# 2.初始化
# 2.1 初始化mongodb_adapter
test_mongodb_adapter = MongoDbPersistenceAdapter(
    request_envelope=request_envelope,
    table_name=table_name,
    partition_key_name="device_id",
    attribute_name="my_data",
    partition_keygen=device_id_partition_keygen)

# mongo_client
mongo_client = pymongo.MongoClient('mongodb://ip', 27017)
db_name="azero_skill"
# 2.2自定义初始化mongodb_adapter
test_mongodb_adapter = MongoDbPersistenceAdapter(
     request_envelope=request_envelope,
     table_name=table_name,
     partition_key_name="device_id",
     attribute_name="my_data",
     db_name= db_name,
     mongo_client=mongo_client,
     partition_keygen=device_id_partition_keygen)

# 添加数据
test_mongodb_adapter.save_attributes(request_envelope=request_envelope, attributes=data)

# 查询数据
response = test_mongodb_adapter.get_attributes(request_envelope=request_envelope)
for result in response:
    print(result)

# 删除数据
test_mongodb_adapter.delete_attributes(request_envelope=request_envelope)
```



