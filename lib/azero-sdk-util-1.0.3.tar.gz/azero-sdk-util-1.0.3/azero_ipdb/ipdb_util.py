import ipdb
import os

class Ipdb:
    def __init__(self):
        # self.file_path='/opt/azero/python/bin/ipipfree.ipdb'
        basedir = os.path.abspath(os.path.dirname(__file__))
        self.file_path = basedir+'/ipipfree.ipdb'
        self.db_city = ipdb.City(self.file_path)
        self.db_district = ipdb.District(self.file_path)

    def city(self):
        return self.db_city

    def district(self):
        return self.db_district

ipdb_city = Ipdb().city()
ipdb = Ipdb()