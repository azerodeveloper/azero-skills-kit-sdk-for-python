import logging
import os


def get_skill_id(requestEnvelope):
    if (requestEnvelope is None
            or requestEnvelope.context is None
            or requestEnvelope.context.system is None
            or requestEnvelope.context.system.application is None
            or requestEnvelope.context.system.application.application_id is None):
        return ''
    else:
        return requestEnvelope.context.system.application.application_id

class Logger:

    def __init__(self, logger_name=None):
        formatter = logging.Formatter("%(asctime)s - %(filename)s[line:%(lineno)d] - %(levelname)s: %(message)s")
        stream_handler = logging.StreamHandler()
        stream_handler.setFormatter(formatter)
        logger = logging.getLogger(logger_name)  # No name gives you the root logger
        # logger.setLevel(logging.WARNING)
        logger.setLevel(logging.DEBUG)
        logger.addHandler(stream_handler)

        logdir = './logs'
        # 创建log目录
        if not os.path.exists(logdir):
            os.mkdir(logdir)
        #  创建一个handler，用于写入日志文件
        #  以append模式打开日志文件
        logfile = './logs/python.log'
        file_handler = logging.FileHandler(logfile, encoding='utf-8')
        #  输出到file的log等级的开关
        file_handler.setLevel(logging.INFO)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

        self.logger = logger

    def debug(self, msg='', request_envelope=None, *args):
        skill_id = None
        if request_envelope is not None:
            skill_id = get_skill_id(request_envelope)
        self.logger.debug({'msg': msg, 'skill_id': skill_id,'options':args})
        self.logger.name = "python-skills"

    def info(self, msg='', request_envelope=None, *args):
        skill_id = None
        if request_envelope is not None:
            skill_id = get_skill_id(request_envelope)
        self.logger.info({'msg': msg, 'skill_id': skill_id,'options':args})
        self.logger.name = "python-skills"

    def warn(self, msg='', request_envelope=None, *args):
        skill_id = None
        if request_envelope is not None:
            skill_id = get_skill_id(request_envelope)
        self.logger.warn({'msg': msg, 'skill_id': skill_id,'options':args})
        self.logger.name = "python-skills"

    def error(self, msg='', request_envelope=None, *args):
        skill_id=None
        if request_envelope is not None:
            skill_id = get_skill_id(request_envelope)
        self.logger.error({'msg':msg,'skill_id':skill_id,'options':args})
        self.logger.name = "python-skills"

logger=Logger('python-skills')