
import unittest
import json

# from azero_gps.gps_gaode_util import azero_gaode_reverse
from azero_gps.gps_gaode_util import GaodeReverse
azero_gaode_reverse = GaodeReverse(gaode_key='cdb6f6820f4b0559b500102b1d7ec639');
class TestGaodeGpsUtil(unittest.TestCase):
    def setUp(self):
        print('start')
        # self.test_baidu();
        # self.test_gaode();
        print('end')

    def test_gaode(self):
        lon_lat = [120.7754676800,31.2929881000]
        print('gaode start .......................')
        address_component = azero_gaode_reverse.base_info(lon=lon_lat[0], lat=lon_lat[1])
        print(address_component)
        # country = azero_gaode_reverse.country_name(lon=lon_lat[0], lat=lon_lat[1])
        # print(country)
        # province = azero_gaode_reverse.province_name(lon=lon_lat[0], lat=lon_lat[1])
        # print(province)
        # city = azero_gaode_reverse.city_name(lon=lon_lat[0], lat=lon_lat[1])
        # print(city)
        # district = azero_gaode_reverse.district_name(lon=lon_lat[0], lat=lon_lat[1])
        # print(district)
        # street = azero_gaode_reverse.township_name(lon=lon_lat[0], lat=lon_lat[1])
        # print(street)
        print('gaode end .......................')