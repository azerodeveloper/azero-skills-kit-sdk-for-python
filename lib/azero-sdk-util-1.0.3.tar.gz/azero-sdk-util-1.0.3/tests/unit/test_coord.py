import unittest
from azero_coord import coord_util

class TestAzeroConfig(unittest.TestCase):
    def setUp(self):
        print('start')
        print('end')

    def test(self):
        print(coord_util.distance(121.346743,31.225815, 119.551165,31.185879))
        print(coord_util.bd2amap(121.346743,31.225815))
        print(coord_util.amap2bd(121.346743,31.225815))
        print(coord_util.wgs2amap(121.346743,31.225815))
        print(coord_util.amap2wgs(121.346743,31.225815))
