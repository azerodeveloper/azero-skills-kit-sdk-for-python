
import unittest

from azero_gps.coord_type_enum import CoordTypeEnum
from azero_gps import GpsReverse

# coord_type = CoordType.GAODE.value
# azero_gps_reverse = GpsReverse( 'cdb6f6820f4b0559b500102b1d7ec639', coord_type)
# from azero_gps import azero_gps_reverse
class TestBaiduGpsUtil(unittest.TestCase):
    def setUp(self):
        print('start')
        print('end')

    def test_baidu(self):
        # 初始化的参数
        ## key: 高德开发平台 》 web服务Key  或者  百度地图开放平台 》 服务端Key
        ### 缺省默认取环境变量中的GAODE_KEY 或者 BAIDU_KEY
        ## coord_type: 高德坐标  或者  百度坐标  枚举值为：CoordTypeEnum
        ### 缺省默认为高德坐标
        azero_baidu_reverse = GpsReverse(key='iHY8lxYuepNcGMSsvqW3cQHwAZApIbSG', coord_type=CoordTypeEnum.BAIDU)
        azero_gps_reverse = GpsReverse(key='cdb6f6820f4b0559b500102b1d7ec639', coord_type=CoordTypeEnum.GAODE)
        lon_lat = [120.673636,31.13641]
        print(' start .......................')
        address_baidu_component = azero_baidu_reverse.base_info(lon_lat[0], lon_lat[1])
        print(address_baidu_component)
        # 查询返回行政区划基本信息
        address_gaode_component = azero_gps_reverse.base_info(lon_lat[0], lon_lat[1])
        print(address_gaode_component)

        # 查询返回行政区划国家名称
        country = azero_gps_reverse.country_name(lon_lat[0], lon_lat[1])
        print(country)

        # 查询返回行政区划省份名称
        province = azero_gps_reverse.province_name(lon_lat[0], lon_lat[1])
        print(province)

        # 查询返回行政区划城市名称
        city = azero_gps_reverse.city_name(lon_lat[0], lon_lat[1])
        print(city)

        # 查询返回行政区划区县名称
        district = azero_gps_reverse.district_name(lon_lat[0], lon_lat[1])
        print(district)

        # 查询返回行政区划乡镇街道名称
        township = azero_gps_reverse.township_name(lon_lat[0], lon_lat[1])
        print(township)
        print(' end .......................')