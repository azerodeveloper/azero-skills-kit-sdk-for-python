
import unittest

from azero_ipdb.ipdb_util import ipdb,ipdb_city
class TestIpdbUtil(unittest.TestCase):
    def setUp(self):
        print('start')
        print('end')

    def test_insert(self):
        city = ipdb_city.find_info('114.220.24.57', "CN").city_name
        print(city)
        district = ipdb.district().find_info('114.220.24.57', "CN").district_name
        print(district)