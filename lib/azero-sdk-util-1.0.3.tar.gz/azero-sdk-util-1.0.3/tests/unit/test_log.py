
import unittest
import os

from azero_log.azero_logger import logger

logger.debug("苏州debug")
logger.info("苏州info")
logger.warn("苏州warn")
logger.error("苏州error")