
import unittest
import os

from azero_config.azero_config import config

class TestAzeroConfig(unittest.TestCase):
    def setUp(self):
        print('start')
        print('end')

    def test(self):
        print(config.get_db_user_name())
        print("直接获取系统变量"+os.environ.get('DBUSERNAME'))
        print(config.get_db_user_pwd())
        print("直接获取系统变量"+os.environ.get('DBUSERPWD'))

        print(config.get_db_url())
        print("直接获取系统变量"+os.environ.get('DBURL'))
        print(config.get_db_name())
        print("直接获取系统变量"+os.environ.get('DATABASES'))