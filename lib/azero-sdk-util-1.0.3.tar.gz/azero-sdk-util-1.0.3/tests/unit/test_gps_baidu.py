
import unittest

from azero_gps.gps_baidu_util import azero_baidu_reverse
from azero_gps.gps_baidu_util import BaiduReverse
azero_baidu_reverse = BaiduReverse(baidu_key='iHY8lxYuepNcGMSsvqW3cQHwAZApIbSG');
class TestBaiduGpsUtil(unittest.TestCase):
    def setUp(self):
        print('start')
        # self.test_baidu();
        # self.test_gaode();
        print('end')

    def test_baidu(self):
        lon_lat = [120.673636,31.13641]
        print('baidu start .......................')
        address_component = azero_baidu_reverse.base_info(lon=lon_lat[0], lat=lon_lat[1])
        print(address_component)
        # country = azero_baidu_reverse.country_name(lon=lon_lat[0], lat=lon_lat[1])
        # print(country)
        # province = azero_baidu_reverse.province_name(lon=lon_lat[0], lat=lon_lat[1])
        # print(province)
        # city = azero_baidu_reverse.city_name(lon=lon_lat[0], lat=lon_lat[1])
        # print(city)
        # district = azero_baidu_reverse.district_name(lon=lon_lat[0], lat=lon_lat[1])
        # print(district)
        # street = azero_baidu_reverse.township_name(lon=lon_lat[0], lat=lon_lat[1])
        # print(street)
        print('baidu end .......................')