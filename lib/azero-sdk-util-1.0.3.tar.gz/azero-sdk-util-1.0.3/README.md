# 使用说明

## 注意事项：

### 1.安装项目根目录下lib中的所有安装包(在lib目录下执行pip install xxx.tar.gz)，例如:

```python
pip install azero-sdk-util-*.tar.gz
```

### 2.运行一下命令安装必要库：

```python
pip install ipip-ipdb
```

### 相关功能介绍

支持一下功能：

​		技能日志

​				使用样例：

```python
from azero_log.azero_logger import logger
....
# 第二个参数必传
logger.debug("log message", request_envelope=handler_input.request_envelope)
logger.info("log message", request_envelope=handler_input.request_envelope)
logger.warn("log message", request_envelope=handler_input.request_envelope)
logger.error("log message", request_envelope=handler_input.request_envelope)
```

​		ip解析城市

​				使用样例：

```python
from azero_ipdb.ipdb_util import ipdb_city
...
city = ipdb_city.find_info("114.220.24.57", "CN").city_name
```

​		经纬度处理

​				使用样例：

```python
from azero_coord import coord_util
...
# 距离计算 返回单位米
distance = coord_util.distance(121.346743,31.225815, 119.551165,31.185879)
# 百度经纬度转高德(谷歌)经纬度
print(coord_util.bd2amap(121.346743,31.225815))
# 高德(谷歌)转百度经纬度经纬度
print(coord_util.amap2bd(121.346743,31.225815))
# WGS经纬度转高德(谷歌)经纬度
print(coord_util.wgs2amap(121.346743,31.225815))
# 高德(谷歌)转WGS经纬度经纬度
print(coord_util.amap2wgs(121.346743,31.225815))
```

​		经纬度解析行政区划

​				使用样例：

```python
#============================经纬度反查功能==================================#
"""
功能说明：支持根据百度/高德经纬度反查行政区划(地址)
    1.查询返回行政区划的基本信息
    2.查询返回国家名称
    3.查询返回省份名称
    4.查询返回城市名称
    5.查询返回区县名称
    6.查询返回乡镇街道名称
"""
 
  
###############################Demo 1##################################
from azero_gps.coord_type_enum import CoordTypeEnum
from azero_gps import GpsReverse
  
# 初始化的参数
## key: 高德开发平台 》 web服务Key  或者  百度地图开放平台 》 服务端Key
### 缺省默认取环境变量中的GAODE_KEY 或者 BAIDU_KEY
## coord_type: 高德坐标  或者  百度坐标  枚举值为：CoordTypeEnum
### 缺省默认为高德坐标
azero_gps_reverse = GpsReverse(key=<你的key>, coord_type=CoordTypeEnum.GAODE)
lon_lat = [120.673636,31.13641]
print(' start .......................')
# 查询返回行政区划基本信息
address_gaode_component = azero_gps_reverse.base_info(lon_lat[0], lon_lat[1])
print(address_gaode_component)
# 查询返回行政区划国家名称
country = azero_gps_reverse.country_name(lon_lat[0], lon_lat[1])
print(country)
# 查询返回行政区划省份名称
province = azero_gps_reverse.province_name(lon_lat[0], lon_lat[1])
print(province)
# 查询返回行政区划城市名称
city = azero_gps_reverse.city_name(lon_lat[0], lon_lat[1])
print(city)
# 查询返回行政区划区县名称
district = azero_gps_reverse.district_name(lon_lat[0], lon_lat[1])
print(district)
# 查询返回行政区划乡镇街道名称
township = azero_gps_reverse.township_name(lon_lat[0], lon_lat[1])
print(township)
print(' end .......................')
  
###############################Demo 2##################################
# 默认为高德坐标查询  使用容器中环境变量中配置的高德key
from azero_gps import azero_gps_reverse
lon_lat = [120.673636,31.13641]
print(' start .......................')
# 查询返回行政区划基本信息
address_gaode_component = azero_gps_reverse.base_info(lon_lat[0], lon_lat[1])
print(address_gaode_component)
# 查询返回行政区划国家名称
country = azero_gps_reverse.country_name(lon_lat[0], lon_lat[1])
print(country)
# 查询返回行政区划省份名称
province = azero_gps_reverse.province_name(lon_lat[0], lon_lat[1])
print(province)
# 查询返回行政区划城市名称
city = azero_gps_reverse.city_name(lon_lat[0], lon_lat[1])
print(city)
# 查询返回行政区划区县名称
district = azero_gps_reverse.district_name(lon_lat[0], lon_lat[1])
print(district)
# 查询返回行政区划乡镇街道名称
township = azero_gps_reverse.township_name(lon_lat[0], lon_lat[1])
print(township)
print(' end .......................')
  
###############################Demo 3##################################
# 百度坐标查询  默认使用容器中环境变量中配置的百度key
from azero_gps import azero_baidu_reverse
# 高德坐标查询  默认使用容器中环境变量中配置的百度key
# from azero_gps import azero_gaode_reverse
 
lon_lat = [120.673636,31.13641]
print(' start .......................')
# 查询返回行政区划基本信息
address_gaode_component = azero_baidu_reverse.base_info(lon_lat[0], lon_lat[1])
#address_gaode_component = azero_gaode_reverse.base_info(lon_lat[0], lon_lat[1])
print(address_gaode_component)
# 查询返回行政区划国家名称
country = azero_baidu_reverse.country_name(lon_lat[0], lon_lat[1])
#country = azero_gaode_reverse.country_name(lon_lat[0], lon_lat[1])
print(country)
# 查询返回行政区划省份名称
province = azero_baidu_reverse.province_name(lon_lat[0], lon_lat[1])
#province = azero_gaode_reverse.province_name(lon_lat[0], lon_lat[1])
print(province)
# 查询返回行政区划城市名称
city = azero_baidu_reverse.city_name(lon_lat[0], lon_lat[1])
#city = azero_gaode_reverse.city_name(lon_lat[0], lon_lat[1])
print(city)
# 查询返回行政区划区县名称
district = azero_baidu_reverse.district_name(lon_lat[0], lon_lat[1])
#district = azero_gaode_reverse.district_name(lon_lat[0], lon_lat[1])
print(district)
# 查询返回行政区划乡镇街道名称
township = azero_baidu_reverse.township_name(lon_lat[0], lon_lat[1])
#township = azero_gaode_reverse.township_name(lon_lat[0], lon_lat[1])
print(township)
print(' end .......................')
#============================经纬度反查功能 end==================================#
```

