#! /usr/bin/env python
# -*- coding: utf-8 -*-
try:
    from setuptools import setup
except ImportError:
    from distutils.core import setup
import setuptools

setup(
    name='azero-sdk-util',  # 包的名字
    author='alston',  # 作者
    version='1.0.0',  # 版本号
    license='MIT',

    description='project describe',  # 描述
    long_description='''long description''',
    author_email='liuwenyuan@soundai.com',  # 你的邮箱**
    url='',  # 可以写github上的地址，或者其他地址
    # 包内需要引用的文件夹
    # packages=setuptools.find_packages(exclude=['url2io',]),
    packages=["azero_config","azero_ipdb","azero_log"],
    # keywords='NLP,tokenizing,Chinese word segementation',
    # package_dir={'jieba':'jieba'},
    package_data={'azero_ipdb':['*.*']},

    # 依赖包
    install_requires=[
        # 'kafka >= 1.3.5',
        # 'kafka-python >= 1.4.3',
        # 'kafka-python-log-handler >= 0.0.1.dev12',
    ],
    classifiers=[
        # 'Development Status :: 4 - Beta',
        # 'Operating System :: Microsoft'  # 你的操作系统  OS Independent      Microsoft
        'Intended Audience :: Developers',
        # 'License :: OSI Approved :: MIT License',
        # 'License :: OSI Approved :: BSD License',  # BSD认证
        'Programming Language :: Python',  # 支持的语言
        'Programming Language :: Python :: 3',  # python版本 。。。
        'Programming Language :: Python :: 3.4',
        'Programming Language :: Python :: 3.5',
        'Programming Language :: Python :: 3.6',
        'Topic :: Software Development :: Libraries'
    ],
    zip_safe=True,
)