# 使用说明

## 注意事项：

### 1.安装项目根目录下lib中的所有安装包(在lib目录下执行pip install xxx.tar.gz)，例如:

```python
pip install azero-sdk-util-*.tar.gz
```

### 2.运行一下命令安装必要库：

```python
pip install ipip-ipdb
```

### 相关功能介绍

支持一下功能：

​		技能日志

​				使用样例：

```python
from azero_log.azero_logger import logger
....
# 第二个参数必传
logger.debug("log message", request_envelope=handler_input.request_envelope)
logger.info("log message", request_envelope=handler_input.request_envelope)
logger.warn("log message", request_envelope=handler_input.request_envelope)
logger.error("log message", request_envelope=handler_input.request_envelope)
```

​		ip解析城市

​				使用样例：

```js
from azero_ipdb.ipdb_util import ipdb_city
...
city = ipdb_city.find_info("114.220.24.57", "CN").city_name
```

