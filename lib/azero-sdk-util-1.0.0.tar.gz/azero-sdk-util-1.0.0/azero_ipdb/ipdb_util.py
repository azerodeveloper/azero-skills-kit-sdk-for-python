import ipdb
import os

class Ipdb:
    def __init__(self):
        # self.file_path='/opt/azero/python/bin/ipipfree.ipdb'
        basedir = os.path.abspath(os.path.dirname(__file__))
        print(basedir)
        self.file_path = basedir+'/ipipfree.ipdb'

    def city(self):
        db = ipdb.City(self.file_path)
        return db

ipdb_city = Ipdb().city()