import logging


def get_skill_id(requestEnvelope):
    if (requestEnvelope is None
            or requestEnvelope.context is None
            or requestEnvelope.context.system is None
            or requestEnvelope.context.system.application is None
            or requestEnvelope.context.system.application.application_id is None):
        return ''
    else:
        return requestEnvelope.context.system.application.application_id

class Logger:

    def __init__(self, logger_name=None):
        handler = logging.StreamHandler()
        logger = logging.getLogger(logger_name)  # No name gives you the root logger
        # logger.setLevel(logging.WARNING)
        logger.setLevel(logging.INFO)
        logger.addHandler(handler)
        self.logger = logger

    def debug(self,msg='',request_envelope=None, *args):
        skill_id = None
        if request_envelope is not None:
            skill_id = get_skill_id(request_envelope)
        self.logger.debug({'msg': msg, 'skill_id': skill_id,'options':args})
        self.logger.name = "python-skills"

    def info(self,msg='',request_envelope=None,*args):
        skill_id = None
        if request_envelope is not None:
            skill_id = get_skill_id(request_envelope)
        self.logger.info({'msg': msg, 'skill_id': skill_id,'options':args})
        self.logger.name = "python-skills"

    def warn(self,msg='',request_envelope=None,*args):
        skill_id = None
        if request_envelope is not None:
            skill_id = get_skill_id(request_envelope)
        self.logger.warn({'msg': msg, 'skill_id': skill_id,'options':args})
        self.logger.name = "python-skills"

    def error(self,msg='',request_envelope=None,*args):
        skill_id=None
        if request_envelope is not None:
            skill_id = get_skill_id(request_envelope)
        self.logger.error({'msg':msg,'skill_id':skill_id,'options':args})
        self.logger.name = "python-skills"

logger=Logger('python-skills')