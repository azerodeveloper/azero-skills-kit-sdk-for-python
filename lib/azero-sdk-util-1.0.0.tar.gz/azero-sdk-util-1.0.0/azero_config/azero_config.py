
import os

class Config(object):
    # __db_user_name = os.environ.get('DBUSERNAME')
    # __db_user_pwd = os.environ.get('DBUSERPWD')
    __db_url = os.environ.get('DBURL_ENCRYPTED')
    __db_name = os.environ.get('DATABASES_ENCRYPTED')
    # os.environ['DBUSERNAME'] = ''
    # os.environ['DBUSERPWD'] = ''
    os.environ['DBURL_ENCRYPTED'] = ''
    os.environ['DATABASES_ENCRYPTED'] = ''

    # @classmethod
    # def get_db_user_name(cls):
    #     return cls.__db_user_name
    #
    # @classmethod
    # def get_db_user_pwd(cls):
    #     return cls.__db_user_pwd

    @classmethod
    def get_db_url(cls):
        return cls.__db_url

    @classmethod
    def get_db_name(cls):
        return cls.__db_name


config = Config()