import logging
from typing import Any, Optional

import json
import kafka


ENCODING = "utf-8"
SKILLTOPIC="azero.log.skills.live"


class KafkaLogHandler(logging.StreamHandler):
    def __init__(
        self,
        topic: str,
        key: Optional[str] = None,
        partition: Optional[int] = None,
        raw_logging: bool = False,
        **kwargs: Any,
    ):
        super().__init__()
        self.topic = topic
        self.key = key.encode(ENCODING) if key else None
        self.partition = partition
        self.raw_logging = raw_logging

        self.producer = kafka.KafkaProducer(**kwargs)

    def emit(self, message: logging.LogRecord):
        def _create_dict_without_none_values(**kwargs: Any) -> dict:
            result = {}

            for k, v in kwargs.items():
                if v is not None:
                    result[k] = v

            return result

        # msg=None
        msg_obg = message.msg
        if isinstance(msg_obg,str):
            return
        msg=msg_obg['msg']
        skill_id=msg_obg['skill_id']
        topic = None
        if skill_id is None:
            topic = SKILLTOPIC
        else:
            message.name = skill_id

        if not topic:
            topic = self.topic

        options=msg_obg['options']
        # if message.args is not None and len(message.args) > 0:
        #     options=message.args[0]
        # if self.raw_logging:
        #     value += f" - {message.lineno}: {message.pathname}"
        value = json.dumps({
            "loggerName": message.name,
            "level": message.levelname,
            "path": message.pathname,
            "lineNo": message.lineno,
            "message": msg,
            "options": options,
            "thread": message.threadName,
            "threadId": message.thread
        }, ensure_ascii=False)
        self.producer.send(
            **_create_dict_without_none_values(
                topic=topic,
                value=value.encode(ENCODING),
                key=self.key,
                partition=self.partition,
            )
        )
