import logging
from azero_log import KafkaLog
import os


def get_skill_id(requestEnvelope):
    if (requestEnvelope is None
            or requestEnvelope.context is None
            or requestEnvelope.context.system is None
            or requestEnvelope.context.system.application is None
            or requestEnvelope.context.system.application.application_id is None):
        return ''
    else:
        return requestEnvelope.context.system.application.application_id

class Logger:

    def __init__(self, logger_name=None):
        stream_handler = logging.StreamHandler()
        logger = logging.getLogger(logger_name)  # No name gives you the root logger
        # logger.setLevel(logging.WARNING)
        logger.setLevel(logging.INFO)
        logger.addHandler(stream_handler)

        dir = os.environ.get('bootstrap_servers')
        if dir:
            topic = "azero.log.skills.runtime"
            kafka_handler = KafkaLog.KafkaLogHandler(topic=topic,
                                               key="skills",
                                               bootstrap_servers=dir,
                                               raw_logging=True
                                               )
            logger.addHandler(kafka_handler)


        self.logger = logger

    def debug(self,msg='',request_envelope=None, *args):
        skill_id = None
        if request_envelope is not None:
            skill_id = get_skill_id(request_envelope)
        self.logger.debug({'msg': msg, 'skill_id': skill_id,'options':args})
        self.logger.name = "python-skills"

    def info(self,msg='',request_envelope=None,*args):
        skill_id = None
        if request_envelope is not None:
            skill_id = get_skill_id(request_envelope)
        self.logger.info({'msg': msg, 'skill_id': skill_id,'options':args})
        self.logger.name = "python-skills"

    def warn(self,msg='',request_envelope=None,*args):
        skill_id = None
        if request_envelope is not None:
            skill_id = get_skill_id(request_envelope)
        self.logger.warn({'msg': msg, 'skill_id': skill_id,'options':args})
        self.logger.name = "python-skills"

    def error(self,msg='',request_envelope=None,*args):
        skill_id=None
        if request_envelope is not None:
            skill_id = get_skill_id(request_envelope)
        self.logger.error({'msg':msg,'skill_id':skill_id,'options':args})
        self.logger.name = "python-skills"

logger=Logger('python-skills')